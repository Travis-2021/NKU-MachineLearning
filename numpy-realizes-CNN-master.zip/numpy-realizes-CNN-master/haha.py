#conding=utf-8

import torch
from torch import nn
import matplotlib.pyplot as plt
import numpy as np

moving_mean = np.zeros((4,1,1))
print(np.sum(moving_mean))

